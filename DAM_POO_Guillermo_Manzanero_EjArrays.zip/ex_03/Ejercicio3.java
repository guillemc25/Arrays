public class Ejercicio3 {

    public static void main(String[] args) {

        int n[][] = new int[4][5]; //Matriz para generar los números aleatorios entre 0 y 9
        int nArray[][] = new int[5][6]; //Array Final para mostrar las sumas
        int total = 0;

//Generamos los números aleatorios
        for (int i = 0; i < n.length; i++) {
            for (int j = 0; j < n[i].length; j++) {
                n[i][j] = (int) (Math.random() * 9);
                nArray[i][j] = n[i][j];
                total += nArray[i][j]; // Sumamos para ibtener el total de las columnas
            }

        }

// Sumamos filas de formas horizontal
        for (int i = 0; i < nArray.length - 1; i++) {
            int sumafila = 0;
            for (int j = 0; j < nArray[i].length - 1; j++) {
                sumafila += nArray[i][j];
            }
            nArray[i][n[i].length] = sumafila; // Asignamos en la ultma columna de la fila la suma
        }

// Sumar columnas de formas vertical por ejemplo(De la posición 00 a la 30)
        for (int i = 0; i < nArray.length; i++) {
            int sumacolumna = 0;
            for (int j = 0; j < nArray[i].length - 1; j++) {
                sumacolumna += nArray[j][i]; // Invertimos las posiciones para poder sumar de forma horizontal y tener la suma total en vertical de las columnas
            }


            nArray[n.length][i] = sumacolumna;//Añadimos en la ultima fila el total de las columnas sumadas verticalmente
        }

// A la ultma posición se agrega el total de todas las columnas y filas
        nArray[nArray.length - 1][nArray[0].length - 1] = total;

// Mostramos la matriz
        for (int i = 0; i < nArray.length; i++) {
            for (int j = 0; j < nArray[i].length; j++) {
                System.out.print(nArray[i][j] + "-- ");
                if (nArray.length == j)
                    System.out.println("");
            }
        }
    }
}