import java.util.*;

public class Ejercicio1 {

    public static void main(String args[]){

        int[] miArray= new int[10];
        int NumerosMayores0= 0;
        int NumeroIguales=0;
        int NumerosMenoresaO=0;
        Scanner sc= new Scanner(System.in);



        System.out.println("Introduce lo valores: ");
        //introducimos datos al array

        for(int i = 0; i<miArray.length; i++){

            System.out.println("Valor" +i);

            miArray[i]= sc.nextInt();

        }

        int Aux= miArray[0];


       System.out.println("Datos del Array:");

        for (int i=0; i<miArray.length;i++){
            //mostramos los datos del array
            System.out.println(miArray[i]);
            //Miramos los numeros mayores a 0
            if(miArray[i]>0){
                NumerosMayores0++;

            }

            if(Aux== miArray[i]){

                    NumeroIguales++;
            }

            if(miArray[i]<0){

                NumerosMenoresaO++;

            }


        }

        System.out.println("Numeros mayores a 0: "+ NumerosMayores0);
        System.out.println("Numeros iguales: " +NumeroIguales);
        System.out.println("Numeros menores a 0: " +NumerosMenoresaO);



    }
}
