import java.util.*;

public class Ejercicio2 {

    static int numero;
    static char []arrayLetras= {'T','R','W','A','G','M','Y','F',
            'P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
    public static void main(String args[]) {

        busquedaLetras();


    }

    public static void busquedaLetras(){
        Scanner sc= new Scanner(System.in);
        System.out.println("Escribe los numeros del DNI");

        int DNI= sc.nextInt();

        numero= DNI % 23;

        System.out.println(numero);


        char letraDNI = arrayLetras[numero];

        System.out.println(" La letra del DNI " + DNI + " -- " + letraDNI);
    }
}
